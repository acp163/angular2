package net.javaguides.springboot.helloworldapp.repo;

import net.javaguides.springboot.helloworldapp.bean.Procedure;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

/**
 * Created by Admin on 10/21/2020.
 */
public interface ProcedureRepo extends MongoRepository<Procedure, String> {
        List<Procedure> findByTrxCorrelationId(String trxCorrelationId);
}
