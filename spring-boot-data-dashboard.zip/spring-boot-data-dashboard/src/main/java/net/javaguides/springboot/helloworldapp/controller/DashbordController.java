package net.javaguides.springboot.helloworldapp.controller;
import java.util.List;

import net.javaguides.springboot.helloworldapp.repo.ProcedureRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import net.javaguides.springboot.helloworldapp.bean.Procedure;
/**
 * Created by Admin on 10/21/2020.
 */

@CrossOrigin(origins = "*")
@RestController
@RequestMapping(path = "api/v2")
public class DashbordController {

    @Autowired
    ProcedureRepo procedureRepo;

    @GetMapping("/procedure")
    public ResponseEntity<List<Procedure>> getAllProcedure() {
        try {
            List<Procedure> result = procedureRepo.findAll();
            if (result.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<>(result, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping("/procedure")
    public ResponseEntity<Procedure> saveProcedure(@RequestBody Procedure procedure) {
        try {
            procedure = procedureRepo.save(procedure);
            return new ResponseEntity<>(procedure, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/procedure/tr/{trxCorrelationId}")
    public ResponseEntity<List<Procedure>> getTutorialById(@PathVariable("trxCorrelationId") String trxCorrelationId) {
        List<Procedure> result = procedureRepo.findByTrxCorrelationId(trxCorrelationId);
        if (result.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        } else {
            return new ResponseEntity<>(result, HttpStatus.OK);
        }
    }

}
