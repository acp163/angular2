package net.javaguides.springboot.helloworldapp.bean;

import javax.persistence.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="procedure")
public class Procedure {

    @Id
    private String id;
    private String trxCorrelationId;
    private String appCode;
    private String appDescription;
    private String env;
    private String threadPath;
    private String hostname;
    private String stepDescription;
    private String stepType;
    private String thread;
    private String logTimeStamp="2020-07-02 14:45:28.537";
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getTrxCorrelationId() {
        return trxCorrelationId;
    }
    public void setTrxCorrelationId(String trxCorrelationId) {
        this.trxCorrelationId = trxCorrelationId;
    }
    public String getAppCode() {
        return appCode;
    }
    public void setAppCode(String appCode) {
        this.appCode = appCode;
    }
    public String getAppDescription() {
        return appDescription;
    }
    public void setAppDescription(String appDescription) {
        this.appDescription = appDescription;
    }
    public String getEnv() {
        return env;
    }
    public void setEnv(String env) {
        this.env = env;
    }
    public String getThreadPath() {
        return threadPath;
    }
    public void setThreadPath(String threadPath) {
        this.threadPath = threadPath;
    }
    public String getHostname() {
        return hostname;
    }
    public void setHostname(String hostname) {
        this.hostname = hostname;
    }
    public String getStepDescription() {
        return stepDescription;
    }
    public void setStepDescription(String stepDescription) {
        this.stepDescription = stepDescription;
    }
    public String getStepType() {
        return stepType;
    }
    public void setStepType(String stepType) {
        this.stepType = stepType;
    }
    public String getThread() {
        return thread;
    }
    public void setThread(String thread) {
        this.thread = thread;
    }
    public String getLogTimeStamp() {
        return logTimeStamp;
    }
    public void setLogTimeStamp(String logTimeStamp) {
        this.logTimeStamp = logTimeStamp;
    }
    @Override
    public String toString() {
        return "Procedure [id=" + id + ", trxCorrelationId=" + trxCorrelationId + ", appCode=" + appCode
                + ", appDescription=" + appDescription + ", env=" + env + ", threadPath=" + threadPath + ", hostname="
                + hostname + ", stepDescription=" + stepDescription + ", stepType=" + stepType + ", thread=" + thread
                + ", logTimeStamp=" + "" + "]";
    }
}
