﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientApp
{
    public class OrderDetails
    {
        public string OrderId { get; set; }
        public string ClientId { get; set; }
        public string Symbol { get; set; }
        public string Quantity { get; set; }
        public string MaxPrice { get; set; }
        public string OrderType { get; set; }
    }
}
