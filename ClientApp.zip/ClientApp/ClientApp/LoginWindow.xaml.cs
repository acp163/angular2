﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ClientApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void loginBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                messageLable.Text = "";
                messageLable.Visibility = Visibility.Collapsed;

                var username = userNameTxtBox.Text;
                var password = passwordBox.Password;

                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:51243/api/");

                    var message = new HttpRequestMessage(HttpMethod.Put, "login?username=" + username + "&&password=" + password);

                    var putTask = client.SendAsync(message);

                    var result = putTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsStringAsync();
                        readTask.Wait();

                        var clientId = readTask.Result;
                        OrderInformationWindow orderInfo = new OrderInformationWindow(clientId);
                        orderInfo.Show();
                        Close();
                    }
                    else
                    {
                        messageLable.Text = result.ReasonPhrase;
                        messageLable.Visibility = Visibility.Visible;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Operation Failed : " + ex.Message);
            }
        }

        private void clearBtn_Click(object sender, RoutedEventArgs e)
        {
            ClearAll(); 
        }

        private void ClearAll()
        {
            messageLable.Text = "";
            messageLable.Visibility = Visibility.Collapsed;

            userNameTxtBox.Clear();
            passwordBox.Clear();
        }

        private void registerBtn_Click(object sender, RoutedEventArgs e)
        {
            RegistrationWindow regWindow = new RegistrationWindow();
            regWindow.Show();
            Close();
        }
    }
}
