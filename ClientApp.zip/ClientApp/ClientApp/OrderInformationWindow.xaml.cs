﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ClientApp
{
    /// <summary>
    /// Interaction logic for OrderInformationWindow.xaml
    /// </summary>
    public partial class OrderInformationWindow : Window
    {
        string clientId;

        List<OrderDetails> Orders = new List<OrderDetails>();

        public OrderInformationWindow(string clientIdReceived)
        {
            InitializeComponent();
            clientId = clientIdReceived;          
            Loaded += OrderInformationWindow_Loaded;
        }

        private void OrderInformationWindow_Loaded(object sender, RoutedEventArgs e)
        {
            GetLatedData();          
        }

        private void GetLatedData()
        {
            try
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:51243/api/");

                    var message = new HttpRequestMessage(HttpMethod.Get, "order?clientId=" + int.Parse(clientId));

                    var putTask = client.SendAsync(message);

                    var result = putTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var ordersJsonString = result.Content.ReadAsStringAsync().Result;

                        Orders = JsonConvert.DeserializeObject<IEnumerable<OrderDetails>>(ordersJsonString).ToList();
                        dataGrid.ItemsSource = Orders;
                    }
                    else
                    {
                        messageLable.Text = result.ReasonPhrase;
                        messageLable.Visibility = Visibility.Visible;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to load orders: " + ex.Message);
            }
        }

        private void placeOrderBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                messageLable.Text = "";
                messageLable.Visibility = Visibility.Collapsed;

                var symbol = symbolTxtBox.Text;
                var quantity = quantityTxtBox.Text;
                var orderType = orderTypeTxtBox.Text;

                if (string.IsNullOrWhiteSpace(symbol))
                {
                    messageLable.Text = "Invalid symbol.";
                    messageLable.Visibility = Visibility.Visible;

                    return;
                }

                if (string.IsNullOrWhiteSpace(quantity))
                {
                    messageLable.Text = "Invalid quantity.";
                    messageLable.Visibility = Visibility.Visible;

                    return;
                }

                double maxPrice;
                if (!double.TryParse(maxPriceTxtBox.Text, out maxPrice))
                {
                    messageLable.Text = "Invalid max price.";
                    messageLable.Visibility = Visibility.Visible;

                    return;
                }

                if (string.IsNullOrWhiteSpace(orderType))
                {
                    messageLable.Text = "Invalid orderType.";
                    messageLable.Visibility = Visibility.Visible;

                    return;
                }

                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:51243/api/");

                    var message = new HttpRequestMessage(HttpMethod.Post, "order?clientId=" + int.Parse(clientId) + "&&symbol=" + symbol + "&&quantity=" + int.Parse(quantity) + "&&maxPrice=" + maxPrice + "&&orderType=" + orderType);

                    var putTask = client.SendAsync(message);

                    var result = putTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        GetLatedData();
                        ClearAll();
                    }
                    else
                    {
                        messageLable.Text = result.ReasonPhrase;
                        messageLable.Visibility = Visibility.Visible;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Operation Failed : " + ex.Message);
            }
        }

        private void ClearAll()
        {
            symbolTxtBox.Clear();
            maxPriceTxtBox.Clear();
            orderTypeTxtBox.Clear();
            quantityTxtBox.Clear();
        }

        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }

        private void PriceValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9.]+");
            e.Handled = regex.IsMatch(e.Text);
        }
    }
}
