CREATE TABLE webapp.Client_info (
    client_id int IDENTITY(1,1) PRIMARY KEY, 
    client_fullname varchar(255),
    client_username varchar(255),
    client_password varchar(255)
);


CREATE TABLE Order_information (
	order_id int IDENTITY(1,1) PRIMARY KEY, 
    client_id int FOREIGN KEY REFERENCES Client_info(client_id),
    symbol varchar(255),
    quantity int,
    max_price DECIMAL(10,2),
    ordertype varchar(255),
);

Insert into Client_info values ('Max Turner', 'max', 'max@123');
Insert into Client_info values ('John Norway', 'john', 'john@123');
Insert into Client_info values ('Merry Thomas', 'merry', 'merry@123');
Insert into Client_info values ('Stuart Belly', 'stu', 'stu@123');


CREATE TABLE webapp.Client_info (
    client_id int NOT NULL AUTO_INCREMENT,  
    client_fullname varchar(255),
    client_username varchar(255),
    client_password varchar(255),
    PRIMARY KEY (client_id)
);


CREATE TABLE webapp.Order_information (
	order_id int NOT NULL AUTO_INCREMENT, 
    client_id int,
    symbol varchar(255),
    quantity int,
    max_price DECIMAL(10,2),
    ordertype varchar(255),
     PRIMARY KEY (order_id)
);

Insert into webapp.Client_info values ('Max Turner', 'max', 'max@123');
Insert into webapp.Client_info values ('John Norway', 'john', 'john@123');
Insert into webapp.Client_info values ('Merry Thomas', 'merry', 'merry@123');
Insert into webapp.Client_info values ('Stuart Belly', 'stu', 'stu@123');



================
CREATE TABLE webapp.Client_info (
    client_id int NOT NULL AUTO_INCREMENT,  
    client_fullname varchar(255),
    client_username varchar(255),
    client_password varchar(255),
    PRIMARY KEY (client_id)
);


CREATE TABLE webapp.Order_information (
	order_id int NOT NULL AUTO_INCREMENT, 
    client_id int,
    symbol varchar(255),
    quantity int,
    max_price DECIMAL(10,2),
    ordertype varchar(255),
     PRIMARY KEY (order_id)
);

Insert into webapp.Client_info values ('Max Turner', 'max', 'max@123');
Insert into webapp.Client_info values ('John Norway', 'john', 'john@123');
Insert into webapp.Client_info values ('Merry Thomas', 'merry', 'merry@123');
Insert into webapp.Client_info values ('Stuart Belly', 'stu', 'stu@123');