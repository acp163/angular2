﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Results;

namespace ServerWebAPI.Controller
{
    public class LoginController : ApiController
    {
        // GET api/<controller>/5
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<controller>
        public IHttpActionResult Post(string fullName, string username, string password)
        {
            string connetionString = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;
            string sql = "Select * from Client_info where client_username = @username";
            try
            {
                var cnn = new MySqlConnection(connetionString);

                cnn.Open();

                var cmd = new MySqlCommand(sql, cnn);
                cmd.Parameters.AddWithValue("@username", username);

                cmd.Prepare();

                MySqlDataReader dataReader = cmd.ExecuteReader();

                IHttpActionResult res;
                if (dataReader.HasRows)
                {
                    dataReader.Close();
                    res = new ResponseMessageResult(new HttpResponseMessage() { ReasonPhrase = "Username already exists.", StatusCode = HttpStatusCode.InternalServerError });
                }
                else
                {
                    sql = "Insert into Client_info (client_fullname, client_username, client_password) values (@fullName, @username, @password);";
                    cmd = new MySqlCommand(sql, cnn);
                    cmd.Parameters.AddWithValue("@fullName", fullName);
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.Parameters.AddWithValue("@password", password);

                    dataReader.Close();

                    var i = cmd.ExecuteNonQuery();
                    if (i > 0)
                    {
                        res = Ok();
                    }
                    else
                    {
                        res = new ResponseMessageResult(new HttpResponseMessage() { ReasonPhrase = "Failed to register user.", StatusCode = HttpStatusCode.InternalServerError });
                    }
                }
                cnn.Close();
                return res;
            }
            catch (Exception ex)
            {
                return new ExceptionResult(ex, this);
            }
        }

        // PUT api/<controller>/5
        public IHttpActionResult Put(string username, string password)
        {
            string connetionString = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;
            string sql = "Select * from Client_info where client_username = @username and client_password = @password";
             try
            {
                var cnn = new MySqlConnection(connetionString);

                    cnn.Open();

                    var cmd = new MySqlCommand(sql, cnn);
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.Parameters.AddWithValue("@password", password);

                    cmd.Prepare();

                    MySqlDataReader dataReader = cmd.ExecuteReader();

                    IHttpActionResult res;

                    if (dataReader.HasRows)
                    {
                        if (dataReader.Read())
                        {
                            var clientId = dataReader[0].ToString();
                            res = Ok(int.Parse(clientId));
                        }
                        else
                        {
                            res = new ResponseMessageResult(new HttpResponseMessage() { ReasonPhrase = "Something wrong with client ID.", StatusCode = HttpStatusCode.InternalServerError });
                        }
                    }
                    else
                    {
                        res = new ResponseMessageResult(new HttpResponseMessage() { ReasonPhrase = "Username or password incorrect.", StatusCode = HttpStatusCode.InternalServerError });
                    }

                    cnn.Close();

                return res;
            }
            catch (Exception ex)
            {
                return new ResponseMessageResult(new HttpResponseMessage() { ReasonPhrase = ex.Message, StatusCode = HttpStatusCode.InternalServerError });
            }
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }
}