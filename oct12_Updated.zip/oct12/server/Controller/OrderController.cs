﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Results;

namespace ServerWebAPI.Controller
{
    public class OrderController : ApiController
    {
        // GET api/<controller>
        public IHttpActionResult Get(int clientId)
        {
            string connetionString = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;
            string sql = "Select * from Order_info where client_id = @clientId";
            try
            {
                var cnn = new MySqlConnection(connetionString);

                cnn.Open();

                var cmd = new MySqlCommand(sql, cnn);
                cmd.Parameters.AddWithValue("@clientId", clientId);

                cmd.Prepare();

                MySqlDataReader dataReader = cmd.ExecuteReader();

                IHttpActionResult res;

                if (dataReader.HasRows)
                {
                    List<OrderDetails> list = new List<OrderDetails>();
                    while (dataReader.Read())
                    {
                        var orderId = dataReader[0].ToString();
                        var symbol = dataReader[2].ToString();
                        var quantity = dataReader[3].ToString();
                        var maxPrice = dataReader[4].ToString();
                        var orderType = dataReader[5].ToString();

                        list.Add( new OrderDetails() {
                            OrderId = orderId, 
                            ClientId = clientId.ToString(),
                            Symbol = symbol,
                            Quantity = quantity,
                            MaxPrice = maxPrice,
                            OrderType = orderType
                        });
                    }

                    res = Ok(list);
                }
                else
                {
                    res = new ResponseMessageResult(new HttpResponseMessage() { ReasonPhrase = "No Data Found for this user.", StatusCode = HttpStatusCode.InternalServerError });
                }

                dataReader.Close();
                cnn.Close();

                return res;
            }
            catch (Exception ex)
            {
                return new ResponseMessageResult(new HttpResponseMessage() { ReasonPhrase = ex.Message, StatusCode = HttpStatusCode.InternalServerError });
            }
        }

        public IHttpActionResult Get()
        {
            string connetionString = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;
            string sql = "Select * from Order_info";
            try
            {
                var cnn = new MySqlConnection(connetionString);

                cnn.Open();

                var cmd = new MySqlCommand(sql, cnn);

                cmd.Prepare();

                MySqlDataReader dataReader = cmd.ExecuteReader();

                IHttpActionResult res;

                if (dataReader.HasRows)
                {
                    List<OrderDetails> list = new List<OrderDetails>();
                    while (dataReader.Read())
                    {
                        var orderId = dataReader[0].ToString();
                        var clientId = dataReader[1].ToString();
                        var symbol = dataReader[2].ToString();
                        var quantity = dataReader[3].ToString();
                        var maxPrice = dataReader[4].ToString();
                        var orderType = dataReader[5].ToString();

                        list.Add(new OrderDetails()
                        {
                            OrderId = orderId,
                            ClientId = clientId,
                            Symbol = symbol,
                            Quantity = quantity,
                            MaxPrice = maxPrice,
                            OrderType = orderType
                        });
                    }

                    res = Ok(list);
                }
                else
                {
                    res = new ResponseMessageResult(new HttpResponseMessage() { ReasonPhrase = "No Data Found for this user.", StatusCode = HttpStatusCode.InternalServerError });
                }

                dataReader.Close();
                cnn.Close();

                return res;
            }
            catch (Exception ex)
            {
                return new ResponseMessageResult(new HttpResponseMessage() { ReasonPhrase = ex.Message, StatusCode = HttpStatusCode.InternalServerError });
            }
        }

        // POST api/<controller>
        public IHttpActionResult Post(int clientId, string symbol, int quantity, double maxPrice, string orderType)
        {
            string connetionString = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;
            string sql = "Insert into Order_info (client_id, symbol,quantity,max_price,ordertype ) values (@clientId, @symbol, @quantity, @maxPrice, @orderType);";
           
            try
            {
                var cnn = new MySqlConnection(connetionString);

                cnn.Open();

                var command = new MySqlCommand(sql, cnn);
                command.Parameters.AddWithValue("@clientId", clientId);
                command.Parameters.AddWithValue("@symbol", symbol);
                command.Parameters.AddWithValue("@quantity", quantity);
                command.Parameters.AddWithValue("@maxPrice", maxPrice);
                command.Parameters.AddWithValue("@orderType", orderType);

                var i = command.ExecuteNonQuery();

                IHttpActionResult res;

                if (i > 0)
                {
                    res = Ok();
                }
                else
                {
                    res = new ResponseMessageResult(new HttpResponseMessage() { ReasonPhrase = "Failed to place order.", StatusCode = HttpStatusCode.InternalServerError });
                }

                command.Dispose();
                cnn.Close();

                return res;
            }
            catch (Exception ex)
            {
                return new ExceptionResult(ex, this);
            }
        }

        // PUT api/<controller>/5
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }
}