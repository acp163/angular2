﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ClientApp
{
    /// <summary>
    /// Interaction logic for RegistrationWindow.xaml
    /// </summary>
    public partial class RegistrationWindow : Window
    {

        public RegistrationWindow()
        {
            InitializeComponent();
        }

        private void registerBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                messageLable.Text = "";
                messageLable.Visibility = Visibility.Collapsed;

                var fullname = fullNameTxtBox.Text;
                var username = userNameTxtBox.Text;
                var password = passwordBox.Password;

                if (string.IsNullOrWhiteSpace(fullname))
                {
                    messageLable.Text = "Invalid fullname.";
                    messageLable.Visibility = Visibility.Visible;

                    return;
                }

                if (string.IsNullOrWhiteSpace(username))
                {
                    messageLable.Text = "Invalid username.";
                    messageLable.Visibility = Visibility.Visible;

                    return;
                }

                if (string.IsNullOrWhiteSpace(password))
                {
                    messageLable.Text = "Invalid password.";
                    messageLable.Visibility = Visibility.Visible;

                    return;
                }


                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:51243/api/");

                    var message = new HttpRequestMessage(HttpMethod.Post, "login?fullname=" + fullname + "&&username=" + username + "&&password=" + password);

                    var putTask = client.SendAsync(message);

                    var result = putTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        messageLable.Text = "Registered successfully.";
                        messageLable.Visibility = Visibility.Visible;
                    }
                    else
                    {
                        messageLable.Text = result.ReasonPhrase;
                        messageLable.Visibility = Visibility.Visible;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Operation Failed : " + ex.Message);
            }
        }

        private void clearBtn_Click(object sender, RoutedEventArgs e)
        {
            messageLable.Text = string.Empty;
            fullNameTxtBox.Clear();
            userNameTxtBox.Clear();
            passwordBox.Clear();
        }

        private void loginBtn_Click(object sender, RoutedEventArgs e)
        {
            LoginWindow loginWindow = new LoginWindow();
            loginWindow.Show();
            Close();
        }
    }
}
