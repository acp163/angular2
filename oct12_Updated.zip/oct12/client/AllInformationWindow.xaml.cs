﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ClientApp
{
    /// <summary>
    /// Interaction logic for AllInformationWindow.xaml
    /// </summary>
    public partial class AllInformationWindow : Window
    {
        public AllInformationWindow()
        {
            InitializeComponent();
            Loaded += AllInformationWindow_Loaded;
        }

        private void AllInformationWindow_Loaded(object sender, RoutedEventArgs e)
        {
            GetAllData();
        }

        private void GetLatedData()
        {
            try
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:51243/api/");

                    var message = new HttpRequestMessage(HttpMethod.Get, "order");

                    var putTask = client.SendAsync(message);

                    var result = putTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        var ordersJsonString = result.Content.ReadAsStringAsync().Result;

                        Orders = JsonConvert.DeserializeObject<IEnumerable<OrderDetails>>(ordersJsonString).ToList();
                        dataGrid.ItemsSource = Orders;
                    }
                    else
                    {
                        messageLable.Text = result.ReasonPhrase;
                        messageLable.Visibility = Visibility.Visible;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to load orders: " + ex.Message);
            }
        }


        private void logoutBtn_Click(object sender, RoutedEventArgs e)
        {
            LoginWindow loginWindow = new LoginWindow();
            loginWindow.Show();
            Close();
        }
    }
}
