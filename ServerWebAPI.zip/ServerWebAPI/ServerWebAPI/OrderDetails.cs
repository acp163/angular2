﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServerWebAPI
{
    public class OrderDetails
    {
        public string OrderId { get; set; }
        public string ClientId { get; set; }
        public string Symbol { get; set; }
        public string Quantity { get; set; }
        public string MaxPrice { get; set; }
        public string OrderType { get; set; }

    }
}