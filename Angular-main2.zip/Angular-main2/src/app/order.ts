export class Order {

    order_id:number; 
    symbol: String;

    quantity: string;

    max_price: string;

    order_price: string;

}
