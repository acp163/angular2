import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthenticationService, User } from './auth.service';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  public username: string;
  public password: string;
  public errorMessage = 'Invalid Credentials';
  public successMessage: string;
  public invalidLogin = false;
  public loginSuccess = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private authenticationService: AuthenticationService) { }

  ngOnInit() {
  }

  handleLoginSecond() {
    this.authenticationService.getUserDetails(this.username).subscribe((result: User) => {

      if (result !== null && result.username !== undefined) {
        if (this.username === result.username && this.password === result.password) {

          this.invalidLogin = false;
          this.loginSuccess = true;
          this.successMessage = 'Login Successful.';
          alert("Login Successful.");
          this.router.navigate(['/hello-world']);
          localStorage.setItem('userid', result.id.toString());
          this.router.navigate(['/order']);
        } else {
          alert("Login unsuccessful,Please check the password");
          this.invalidLogin = true;
          this.loginSuccess = false;
        }
      } else {

        alert("You have not registered yet");
        this.invalidLogin = true;
        this.loginSuccess = false;
        this.errorMessage = "You have not registered yet";
      }
      // end else block
    },
      (err: HttpErrorResponse) => console.log(`Got error: ${err}`)
    ) //end subscribe block
  }

  handleLogin() {
    this.authenticationService.authenticationService(this.username, this.password).subscribe((result) => {
      this.invalidLogin = false;
      this.loginSuccess = true;
      this.successMessage = 'Login Successful.';
      //this.router.navigate(['/hello-world']);
      this.router.navigate(['/order']);


    }, () => {
      this.invalidLogin = true;
      this.loginSuccess = false;
    });
  }
}
