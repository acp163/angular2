import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from '../login/auth.service';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  constructor(private http: HttpClient) {

  }

  saveOrderDetails(formValue) {

    console.log(formValue);
    return this.http.post("http://localhost:8080/api/v1/order", formValue);
  }
}

export interface orders {
  symbol: string,
  quantity: number,
  maxPrice: number,
  orderType: string,
  user: User

}
