import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthenticationService, User } from '../login/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  public username: string;
  public password: string;
  public errorMessage = 'Invalid Credentials';
  public successMessage: string;
  public invalidLogin = false;
  public loginSuccess = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private authenticationService: AuthenticationService) { }

  ngOnInit(): void {
  }

  handleRegisteration(formValue) {

    this.authenticationService.saveUserDetails(formValue).subscribe((data: User) => {
      if (data !== null && data.username !== undefined) {
        this.invalidLogin = false;
        this.loginSuccess = true;
        this.successMessage = 'You have successfully added. please login again!!';
        alert(this.successMessage);
        this.router.navigate(['/hello-world']);
        this.router.navigate(['/login']);
      } else {
        alert("We have got some problem, please try again");
        this.invalidLogin = true;
        this.loginSuccess = false;
        this.errorMessage = "You have not registered yet";
      }
      // end else block
    },
      (err: HttpErrorResponse) => console.log(`Got error: ${err}`)


    )

  }

}
